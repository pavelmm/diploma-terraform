---
weight: 301
toc: true
title: Deploy to kind
menu:
    docs:
        parent: kube
lead: This guide will help you deploying kube-prometheus on Kubernetes kind.
images: []
draft: false
description: This guide will help you deploying kube-prometheus on Kubernetes kind.
---

Time to explain how!

Your chance of [**contributing**](https://github.com/prometheus-operator/kube-prometheus/blob/main/docs/deploy-kind.md)!
